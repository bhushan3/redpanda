<?php

require get_parent_theme_file_path( 'includes/helper-functions.php' );

require get_parent_theme_file_path( 'includes/class-bem-walker-nav-menu.php' );

require get_parent_theme_file_path( 'includes/theme-setup.php' );
