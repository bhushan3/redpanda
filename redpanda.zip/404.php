<?php get_header(); ?>
	<div id='main' class='main'>
		<section class='section section--no-content'>
			<div class='section__inner content-wrapper'>
				<h1>404.php</h1>
			</div>
		</section>
	</div>
<?php
get_footer();
